<div id="footercontainer">
    <div id="footer">
        <footer>
            <div id="left">
                &copy; DamsCommerce 2017
            </div>
            <div id="right">
                <i>Jan-Willem van Bremen</i>
            </div>
        </footer>
    </div>
</div>
