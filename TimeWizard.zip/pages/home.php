<!--
<?php

echo($_SESSION['L_ID']);
echo($_SESSION['L_NAME']);
echo($_SESSION['L_STATUS']);

?>
-->

<div id=text>

    <h1>TimeWizard</h1>

<p>

TimeWizard is de custom timemanagement/logging service gemaakt door Jan-Willem van Bremen.

    </p>

    <br>

    <h3>DamsCommerce</h3>

    <style>
.embed-container {
    position: relative;
    padding-bottom: 56.25%;
    height: 0;
    overflow: hidden;
    max-width: 100%;
}

.embed-container iframe, .embed-container object, .embed-container embed {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
    </style>
        <div class='embed-container'>

            <iframe src='https://www.damscommerce.nl' frameborder='0' allowfullscreen></iframe>

    </div>

</div>
